"""hacer_figuras.py - Dibuja los diagramas explicativos (SVG hechos a mano, sin librerias)."""
COL = {1: "#2a78d6", 2: "#1baa6b", 3: "#c98500", 4: "#7a4fd0", 5: "#d1552f", 6: "#008a8a", 7: "#5b6470"}
TXT = "#1c2430"; GRIS = "#5b6470"

def caja(x, y, w, h, titulo, lineas, color, chip=None):
    s = f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10" fill="#fff" stroke="{color}" stroke-width="2"/>'
    s += f'<rect x="{x}" y="{y}" width="{w}" height="30" rx="10" fill="{color}"/><rect x="{x}" y="{y+18}" width="{w}" height="12" fill="{color}"/>'
    s += f'<text x="{x+w/2}" y="{y+20}" text-anchor="middle" font-size="14" font-weight="700" fill="#fff">{titulo}</text>'
    for i, l in enumerate(lineas):
        peso = ' font-weight="600"' if l.startswith("*") else ""
        s += f'<text x="{x+w/2}" y="{y+50+i*17}" text-anchor="middle" font-size="12.5" fill="{TXT}"{peso}>{l.lstrip("*")}</text>'
    if chip:
        s += f'<rect x="{x+10}" y="{y+h-28}" width="{w-20}" height="20" rx="10" fill="{color}" opacity=".13"/>'
        s += f'<text x="{x+w/2}" y="{y+h-14}" text-anchor="middle" font-size="11.5" fill="{color}" font-weight="600">{chip}</text>'
    return s

def flecha(x1, y1, x2, y2, texto=None, color=GRIS, punteada=False):
    d = ' stroke-dasharray="6 4"' if punteada else ""
    s = f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="2" marker-end="url(#p)"{d}/>'
    if texto:
        s += f'<text x="{(x1+x2)/2}" y="{(y1+y2)/2-6}" text-anchor="middle" font-size="11" fill="{GRIS}">{texto}</text>'
    return s

def svg(w, h, cuerpo):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}" font-family="system-ui,Segoe UI,Arial">'
            f'<defs><marker id="p" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
            f'<path d="M0,0L10,5L0,10z" fill="{GRIS}"/></marker></defs><rect width="{w}" height="{h}" fill="#fbfcfd"/>{cuerpo}</svg>')

def carril(x, y, w, h, titulo, color):
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="14" fill="{color}" opacity=".06"/>'
            f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="14" fill="none" stroke="{color}" stroke-dasharray="4 4" opacity=".5"/>'
            f'<text x="{x+16}" y="{y+22}" font-size="13" font-weight="700" fill="{color}">{titulo}</text>')

# ---------------- Figura 1: el recorrido completo ----------------
def general():
    c = f'<text x="620" y="34" text-anchor="middle" font-size="21" font-weight="700" fill="{TXT}">Del esquema al veredicto: las 7 fases</text>'
    c += f'<text x="620" y="56" text-anchor="middle" font-size="13" fill="{GRIS}">El esquema se compila UNA vez y queda convertido en una maquina. Esa maquina revisa cada documento mientras va llegando.</text>'
    # carril A: el esquema
    c += carril(20, 74, 1200, 232, "A.  EL ESQUEMA (se hace una sola vez)", "#7a4fd0")
    w, h, y = 208, 150, 112
    xs = [40, 276, 512, 748, 984]
    datos = [(1, "Fase 1 · Lexico", ["*bytes → tokens", "reconoce numeros, cadenas,", "llaves, etiquetas XML"], "AFD (Unidad 2)"),
             (2, "Fase 2 · Sintactico", ["*tokens → arbol", "revisa que este bien", "armado y anidado"], "GLC y arbol de derivacion"),
             (3, "Fase 3 · Semantico", ["*arbol → reglas limpias", "resuelve $ref y clasifica", "verde / amarillo / rojo"], "Jerarquia de Chomsky"),
             (4, "Fase 4 · Automata", ["*reglas → DPDA ponderado", "tabla delta, pila y pesos;", "se minimiza"], "Automata de pila + minimizacion"),
             (5, "Fase 5 · Codigo", ["*DPDA → validador.c / .rs", "tablas, pila fija,", "sin pedir memoria"], "Tabla de transicion")]
    for x, (n, t, l, chip) in zip(xs, datos):
        c += caja(x, y, w, h, t, l, COL[n], chip)
    for a, b in zip(xs, xs[1:]):
        c += flecha(a + w, y + 75, b - 2, y + 75)
    c += f'<text x="40" y="290" font-size="12" fill="{GRIS}">Entra: JSON Schema, DTD o XSD</text>'
    c += f'<text x="1192" y="290" text-anchor="end" font-size="12" fill="{GRIS}">Sale: M = (Q, Σ, Γ, δ, q0, Z0, F, w) y su codigo en C y Rust</text>'
    # carril B: cada documento
    c += carril(20, 326, 1200, 250, "B.  CADA DOCUMENTO (en tiempo real, por bloques)", "#008a8a")
    yb = 366
    c += caja(40, yb, 190, 150, "Documento", ["*llega en pedazos", '{"id": 7, "ta', 'gs": ["a"]}', "(nunca se guarda entero)"], "#1c2430")
    c += caja(290, yb, 200, 150, "Lexer (el mismo AFD)", ["*bytes → tokens", "{  CADENA  :  NUMERO", ",  CADENA  :  [ ...", "con linea, columna y byte"], COL[1])
    c += caja(550, yb, 230, 150, "DPDA en marcha", ["*estado + tope de pila + token", "→ una fila de la tabla δ", "apila { [  ·  desapila } ]", "suma el peso de cada regla"], COL[4], "O(n) tiempo · O(d) pila")
    c += caja(840, yb, 170, 150, "Veredicto", ["*VALIDO o INVALIDO", "ruta: /tags/0", "posicion: byte 21", "costo y violaciones"], "#1b7f3b")
    c += caja(1040, yb, 160, 150, "Fase 6 · Medir", ["*MB/s, ciclos/byte", "memoria, pila,", "asignaciones", "vs. linea base (DOM)"], COL[6])
    c += flecha(230, yb + 75, 288, yb + 75) + flecha(490, yb + 75, 548, yb + 75) + flecha(780, yb + 75, 838, yb + 75)
    c += flecha(1010, yb + 75, 1038, yb + 75, punteada=True)
    c += f'<text x="620" y="552" text-anchor="middle" font-size="12" fill="{GRIS}">Limites que cortan a tiempo: profundidad de pila, tamano en bytes y tiempo. Si el documento esta mal formado, se dice donde.</text>'
    # union A -> B
    c += f'<path d="M800,262 L800,300 Q800,312 788,312 L677,312 Q665,312 665,324 L665,364" fill="none" stroke="{COL[4]}" stroke-width="2" marker-end="url(#p)"/>'
    c += f'<text x="732" y="306" text-anchor="middle" font-size="11.5" fill="{COL[4]}" font-weight="600">la tabla δ</text>'
    # carril C: la web
    c += carril(20, 596, 1200, 104, "C.  FASE 7 · LA PAGINA WEB (API REST + WebSocket)", "#5b6470")
    for i, t in enumerate(["Editor de esquema y documento", "Automata y arbol dibujados", "Descarga del codigo C y Rust", "Streaming: la pila en vivo", "Comparacion de motores", "Casos de prueba (143)"]):
        x = 40 + i * 196
        c += f'<rect x="{x}" y="632" width="184" height="48" rx="8" fill="#fff" stroke="{COL[7]}" stroke-width="1.5"/>'
        c += f'<text x="{x+92}" y="661" text-anchor="middle" font-size="11.5" fill="{TXT}">{t}</text>'
    return svg(1240, 720, c)

# ---------------- Figura 2: temas del curso -> fases ----------------
def temas():
    c = f'<text x="560" y="34" text-anchor="middle" font-size="21" font-weight="700" fill="{TXT}">Que tema del curso se usa en cada fase</text>'
    c += f'<text x="560" y="56" text-anchor="middle" font-size="13" fill="{GRIS}">Linea continua: ya visto en clase (Unidades 1 y 2).  Linea punteada: esta en el programa del curso y hubo que estudiarlo para el proyecto.</text>'
    izq = [("I. Preliminares", "alfabeto, cadena, lenguaje · Chomsky", "#2a78d6", True),
           ("II. AFD", "definicion formal, tabla de transicion", "#2a78d6", True),
           ("II. AFND y movimientos ε", "conversion a AFD por subconjuntos", "#2a78d6", True),
           ("II. Minimizacion", "refinamiento de particiones", "#2a78d6", True),
           ("III. Expresiones regulares", "ER ↔ automata finito (Thompson)", "#c98500", False),
           ("IV. Gramaticas libres de contexto", "arbol de derivacion, parsing LL(1)", "#c98500", False),
           ("IV. Automata de pila (push-down)", "pila, relacion con las GLC", "#c98500", False),
           ("IV. Lema de bombeo", "u vᵏ x yᵏ z", "#c98500", False),
           ("VI. Complejidad", "O(n) en tiempo, O(d) en pila", "#c98500", False)]
    der = [("Fase 1 · Lexico", COL[1]), ("Fase 2 · Sintactico", COL[2]), ("Fase 3 · Semantico", COL[3]), ("Fase 4 · DPDA (JSON)", COL[4]),
           ("Fase 4 · DPDA (XML: DTD y XSD)", COL[4]), ("Fase 5 · Codigo C y Rust", COL[5]), ("Fase 6 · Tiempo real y pruebas", COL[6]), ("Fase 7 · Web (las muestra todas)", COL[7])]
    yi = lambda i: 84 + i * 62
    yd = lambda j: 96 + j * 68
    for i, (t, sub, col, visto) in enumerate(izq):
        c += f'<rect x="30" y="{yi(i)}" width="330" height="50" rx="9" fill="#fff" stroke="{col}" stroke-width="2"/>'
        c += f'<text x="44" y="{yi(i)+21}" font-size="13.5" font-weight="700" fill="{TXT}">{t}</text><text x="44" y="{yi(i)+39}" font-size="12" fill="{GRIS}">{sub}</text>'
    for j, (t, col) in enumerate(der):
        c += f'<rect x="770" y="{yd(j)}" width="320" height="44" rx="9" fill="{col}"/><text x="930" y="{yd(j)+27}" text-anchor="middle" font-size="14" font-weight="700" fill="#fff">{t}</text>'
    enlaces = [(0, 0), (0, 2), (1, 0), (1, 5), (2, 4), (3, 3), (3, 4), (4, 4), (5, 1), (5, 2), (6, 3), (6, 4), (6, 5), (7, 6), (8, 6), (0, 3)]
    for i, j in enlaces:
        col, visto = izq[i][2], izq[i][3]
        d = "" if visto else ' stroke-dasharray="6 4"'
        c += f'<path d="M360,{yi(i)+25} C560,{yi(i)+25} 570,{yd(j)+22} 768,{yd(j)+22}" fill="none" stroke="{col}" stroke-width="1.8" opacity=".75"{d} marker-end="url(#p)"/>'
    c += f'<text x="560" y="662" text-anchor="middle" font-size="12.5" fill="{GRIS}">Fuera del programa del curso: pesos del semianillo tropical (min, +), UTF-8, generacion de codigo y WebSocket.   No se uso: Maquina de Turing (Unidad V).</text>'
    return svg(1120, 684, c)

open("diagrama_general.svg", "w", encoding="utf-8").write(general())
open("temas_del_curso.svg", "w", encoding="utf-8").write(temas())
print("ok")
