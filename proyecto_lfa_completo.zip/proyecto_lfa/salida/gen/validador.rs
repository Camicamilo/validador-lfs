// validador.rs - GENERADO por generador_v1.py (Fase 5). No editar a mano.
// Validador nativo de UN esquema: automata de pila determinista ponderado.
// Compilar:   rustc -O --edition 2021 -o validador_rs validador.rs
// Biblioteca: rustc -O --edition 2021 --crate-type cdylib -o libvalidador_rs.so validador.rs
#![allow(dead_code, unused_unsafe, non_upper_case_globals, clippy::all)]
const ERR_MAX: usize = 16;      // errores que se guardan con su ruta (se cuentan todos)
const RUTA_MAX: usize = 256;
const CLAVE_MAX: usize = 64;
const NUM_MAX: usize = 512;
// ===== TABLAS generadas a partir del esquema (son DATOS, no logica) =====
// DPDA: 22 estados, 69 filas de delta, 5 simbolos de pila, 13 simbolos de entrada
// estados: 0=V0 1=B2 2=B* 3=C0.? 4=C0.id 5=C0.tags 6=C*.? 7=E2 8=E* 9=G2 10=G* 11=K0 12=K* 13=M0 14=M* 15=N0 16=N* 17=R 18=V1 19=V2 20=V* 21=qF
// pila:    0=Z0 1=A2 2=A* 3=O0 4=O*
const PILA_MAX: usize = 1024;   // profundidad maxima de la pila
const BUF_MAX: usize = 64;
const NQ: usize = 22;
const NA: usize = 13;
const NFILAS: usize = 69;
const Q_F: usize = 21;
const S_OTRA: usize = 11;
const S_EPS: usize = 12;
const SC_C1: usize = 1;
const SC_C3: usize = 3;
const SC_C4: usize = 4;
const SC_C7: usize = 7;
const KC_COMILLA: usize = 2;
const KC_BARRA: usize = 0;
const KC_U: usize = 6;
const LN_NC: usize = 7;
static LN_CLASE: [u8; 256] = [
  6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
  6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 3, 6, 4, 5, 6, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 6, 6, 6, 6, 6,
  6, 6, 6, 6, 6, 2, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
  6, 6, 6, 6, 6, 2, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
  6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
  6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
  6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
  6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6];
static LN_TRANS: [i8; 63] = [
  2, 3, -1, -1, 1, -1, -1, 2, 3, -1, -1, -1, -1, -1, -1, -1, 6, -1, -1, 4, -1, 3, 3, 6, -1, -1, 4, -1, 5, 5, -1, -1,
  -1, -1, -1, 5, 5, 6, -1, -1, -1, -1, 8, 8, -1, 7, 7, -1, -1, 8, 8, -1, -1, -1, -1, -1, 8, 8, -1, -1, -1, -1, -1];
static LN_ACEPTA: [u8; 9] = [
  0, 0, 1, 1, 0, 1, 0, 0, 1];
static LN_NOSIGUE: [u8; 256] = [
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
const LC_NC: usize = 8;
static LC_CLASE: [u8; 256] = [
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
  5, 5, 2, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5,
  5, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 0, 5, 5, 5,
  5, 4, 1, 4, 4, 4, 1, 5, 5, 5, 5, 5, 5, 5, 3, 5, 5, 5, 3, 5, 3, 6, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
  5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
  5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
  5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
  5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5];
static LC_TRANS: [i8; 64] = [
  -1, -1, 1, -1, -1, -1, -1, -1, 3, 1, 2, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, 4, -1,
  -1, 5, -1, -1, 5, -1, -1, -1, -1, 6, -1, -1, 6, -1, -1, -1, -1, 7, -1, -1, 7, -1, -1, -1, -1, 1, -1, -1, 1, -1, -1, -1];
static LC_ACEPTA: [u8; 8] = [
  0, 0, 1, 0, 0, 0, 0, 0];
static LC_NOSIGUE: [u8; 256] = [
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
const LL_NC: usize = 10;
static LL_CLASE: [u8; 256] = [
  9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
  9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
  9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
  9, 0, 9, 9, 9, 1, 2, 9, 9, 9, 9, 9, 3, 9, 4, 9, 9, 9, 5, 6, 7, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
  9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
  9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
  9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
  9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9];
static LL_TRANS: [i8; 140] = [
  -1, -1, 5, -1, 10, -1, -1, 1, -1, -1, -1, -1, -1, -1, -1, 2, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 3, -1, -1, 4,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 6, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 7,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 8, -1, -1, -1, -1, 9, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 11, -1, -1, -1, -1, 12, -1, -1, -1, -1, -1, -1, -1, -1, -1, 13, -1, -1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1];
static LL_ACEPTA: [u8; 14] = [
  0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1];
static LL_NOSIGUE: [u8; 256] = [
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
  0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1,
  0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
static SIMBOLO: [i8; 256] = [
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 5, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 4, -1, -1, -1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 2, -1, 3, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, -1, 1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1];
static ALT_INI: [i32; 287] = [
  0, 1, 1, 2, 2, 2, 2, 3, 4, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 7,
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9,
  9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 11, 11, 11,
  11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12,
  12, 12, 12, 13, 13, 13, 13, 13, 13, 13, 13, 13, 14, 14, 15, 16, 16, 16, 17, 18,
  19, 19, 19, 19, 19, 20, 20, 21, 22, 22, 22, 23, 24, 25, 25, 25, 25, 25, 26, 26,
  27, 27, 27, 27, 28, 29, 30, 30, 30, 30, 30, 31, 31, 32, 32, 32, 32, 33, 34, 35,
  35, 35, 35, 35, 35, 36, 36, 36, 36, 36, 36, 36, 36, 37, 38, 39, 39, 39, 40, 40,
  40, 40, 40, 40, 40, 40, 40, 40, 41, 41, 41, 42, 42, 42, 42, 43, 43, 43, 43, 43,
  43, 43, 43, 43, 44, 44, 44, 44, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45,
  45, 45, 45, 45, 45, 46, 47, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48,
  49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 54, 55, 55, 56, 56, 56,
  56, 57, 58, 59, 59, 59, 59, 59, 60, 60, 61, 61, 61, 61, 62, 63, 64, 64, 64, 64,
  64, 65, 65, 66, 66, 66, 66, 67, 68, 69, 69, 69, 69, 69, 69, 69, 69, 69, 69, 69,
  69, 69, 69, 69, 69, 69, 69];
static ALT_TOPE: [i16; 69] = [
  -1, -1, -1, -1, -1, 1, 1, 2, 2, 3, 3, 3, 4, 1, 1, 1, 1, 1, 1, 2,
  2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 3, 3, 3, 4,
  4, 3, 3, 4, 4, 3, 3, 3, 4, 0, 1, 2, 3, 4, -1, -1, -1, -1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1];
static ALT_FILA: [i16; 69] = [
  0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
  20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39,
  40, 41, 42, 43, 44, 45, 46, 47, 48, 53, 50, 49, 52, 51, 54, 55, 56, 57, 58, 59,
  60, 61, 62, 63, 64, 65, 66, 67, 68];
#[derive(Clone, Copy)] struct Fila { dest: i16, pila: u8, push: i16, reg: u8, reg_arg: i8, g_ini: i32, g_n: u8 }
const fn f(dest: i16, pila: u8, push: i16, reg: u8, reg_arg: i8, g_ini: i32, g_n: u8) -> Fila { Fila { dest, pila, push, reg, reg_arg, g_ini, g_n } }
static FILAS: [Fila; 69] = [
  f(11,2,3,0,0,0,1), f(8,2,2,0,0,1,1), f(17,0,0,0,0,2,1), f(17,0,0,0,0,3,1), f(17,0,0,0,0,4,1), f(17,1,0,0,0,5,0),
  f(9,0,0,0,0,5,0), f(17,1,0,0,0,5,0), f(10,0,0,0,0,5,0), f(20,0,0,0,0,5,0), f(18,0,0,0,0,5,0), f(19,0,0,0,0,5,0),
  f(20,0,0,0,0,5,0), f(12,2,4,1,0,5,1), f(8,2,2,1,0,6,1), f(17,1,0,0,0,7,0), f(1,0,0,1,0,7,1), f(1,0,0,1,0,8,1),
  f(1,0,0,1,0,9,1), f(12,2,4,1,0,10,0), f(8,2,2,1,0,10,0), f(17,1,0,0,0,10,0), f(2,0,0,1,0,10,0), f(2,0,0,1,0,10,0),
  f(2,0,0,1,0,10,0), f(12,2,4,1,0,10,1), f(8,2,2,1,0,11,1), f(1,0,0,1,0,12,1), f(1,0,0,1,0,13,1), f(1,0,0,1,0,14,1),
  f(12,2,4,1,0,15,0), f(8,2,2,1,0,15,0), f(2,0,0,1,0,15,0), f(2,0,0,1,0,15,0), f(2,0,0,1,0,15,0), f(17,1,0,0,0,15,1),
  f(4,0,0,2,0,16,1), f(5,0,0,2,1,17,1), f(3,0,0,3,0,18,1), f(17,1,0,0,0,19,0), f(6,0,0,3,0,19,1), f(17,1,0,0,0,20,1),
  f(15,0,0,0,0,21,0), f(17,1,0,0,0,21,0), f(16,0,0,0,0,21,0), f(4,0,0,2,0,21,1), f(5,0,0,2,1,22,1), f(3,0,0,3,0,23,1),
  f(6,0,0,3,0,24,1), f(2,0,0,0,0,25,0), f(1,0,0,0,0,25,0), f(14,0,0,0,0,25,0), f(13,0,0,0,0,25,0), f(21,0,0,0,0,25,0),
  f(12,2,4,0,0,25,1), f(8,2,2,0,0,26,1), f(17,0,0,0,0,27,1), f(17,0,0,0,0,28,1), f(17,0,0,0,0,29,1), f(12,2,4,0,0,30,1),
  f(7,2,1,0,0,31,1), f(17,0,0,0,0,32,1), f(17,0,0,0,0,33,1), f(17,0,0,0,0,34,1), f(12,2,4,0,0,35,0), f(8,2,2,0,0,35,0),
  f(17,0,0,0,0,35,0), f(17,0,0,0,0,35,0), f(17,0,0,0,0,35,0)];
#[derive(Clone, Copy)] struct Guarda { op: u8, costo: u32, a: i64, d: f64, c_ini: i32, c_n: i32 }
const fn g(op: u8, costo: u32, a: i64, d: f64, c_ini: i32, c_n: i32) -> Guarda { Guarda { op, costo, a, d, c_ini, c_n } }
static GUARDAS: [Guarda; 35] = [
  g(0,1,32u64 as i64,0.0f64,0,0), g(0,1,32u64 as i64,0.0f64,0,0), g(0,1,32u64 as i64,0.0f64,0,0), g(0,1,32u64 as i64,0.0f64,0,0),
  g(0,1,32u64 as i64,0.0f64,0,0), g(0,1,1u64 as i64,0.0f64,0,0), g(0,1,1u64 as i64,0.0f64,0,0), g(0,1,1u64 as i64,0.0f64,0,0),
  g(0,1,1u64 as i64,0.0f64,0,0), g(0,1,1u64 as i64,0.0f64,0,0), g(0,1,1u64 as i64,0.0f64,0,0), g(0,1,1u64 as i64,0.0f64,0,0),
  g(0,1,1u64 as i64,0.0f64,0,0), g(0,1,1u64 as i64,0.0f64,0,0), g(0,1,1u64 as i64,0.0f64,0,0), g(10,1,1u64 as i64,0.0f64,0,0),
  g(8,1,0u64 as i64,0.0f64,0,0), g(8,1,1u64 as i64,0.0f64,0,0), g(8,1,18446744073709551615u64 as i64,0.0f64,0,0), g(8,1,18446744073709551615u64 as i64,0.0f64,0,0),
  g(10,1,1u64 as i64,0.0f64,0,0), g(8,1,0u64 as i64,0.0f64,0,0), g(8,1,1u64 as i64,0.0f64,0,0), g(8,1,18446744073709551615u64 as i64,0.0f64,0,0),
  g(8,1,18446744073709551615u64 as i64,0.0f64,0,0), g(0,1,4u64 as i64,0.0f64,0,0), g(0,1,4u64 as i64,0.0f64,0,0), g(0,1,4u64 as i64,0.0f64,0,0),
  g(0,1,4u64 as i64,0.0f64,0,0), g(0,1,4u64 as i64,0.0f64,0,0), g(0,1,64u64 as i64,0.0f64,0,0), g(0,1,64u64 as i64,0.0f64,0,0),
  g(0,1,64u64 as i64,0.0f64,0,0), g(0,1,64u64 as i64,0.0f64,0,0), g(0,1,64u64 as i64,0.0f64,0,0)];
#[derive(Clone, Copy)] struct Konst { tipo: u8, d: f64, s_ini: i32, s_n: i32 }
const fn k(tipo: u8, d: f64, s_ini: i32, s_n: i32) -> Konst { Konst { tipo, d, s_ini, s_n } }
static CONSTS: [Konst; 0] = [
  ];
static BYTES: [u8; 12] = [
  105, 100, 116, 97, 103, 115, 105, 100, 116, 97, 103, 115];
static ES_CLAVE: [u8; 22] = [
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0];
static CLV_INI: [i32; 23] = [
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 4, 4, 4, 4, 4, 4, 4];
#[derive(Clone, Copy)] struct Clave { s_ini: i32, s_n: i32, sim: i16 }
const fn c(s_ini: i32, s_n: i32, sim: i16) -> Clave { Clave { s_ini, s_n, sim } }
static CLAVES: [Clave; 4] = [
  c(0,2,9), c(2,4,10), c(6,2,9), c(8,4,10)];
static ES_ARR: [u8; 5] = [
  0, 1, 1, 0, 0];
static NOMBRE_ERR: [&str; 21] = ["tipo", "nunca", "enum", "const", "minimum", "maximum", "minLength", "maxLength", "dup", "prohibida", "requeridos", "minItems", "maxItems", "sintaxis", "lexico", "incompleto", "sobra", "profundidad", "tamano", "tiempo", "numero_largo"];

// ===== MOTOR (el mismo para cualquier esquema) =====
const T_LLAVE_A: usize = 0; const T_CORCH_A: usize = 2; const T_CADENA: usize = 6; const T_NUMERO: usize = 7; const T_LITERAL: usize = 8;
const A_NADA: u8 = 0; const A_NUM: u8 = 1; const A_CAD: u8 = 2; const A_LIT: u8 = 3;
const G_TIPO: u8 = 0; const G_NUNCA: u8 = 1; const G_ENUM: u8 = 2; const G_CONST: u8 = 3; const G_MIN: u8 = 4; const G_MAX: u8 = 5;
const G_MINLEN: u8 = 6; const G_MAXLEN: u8 = 7; const G_DUP: u8 = 8; const G_PROHIBIDA: u8 = 9; const G_REQ: u8 = 10;
const G_MINITEMS: u8 = 11; const G_MAXITEMS: u8 = 12; const E_SINTAXIS: u8 = 13; const E_LEXICO: u8 = 14; const E_INCOMPLETO: u8 = 15;
const E_SOBRA: u8 = 16; const E_PROFUNDIDAD: u8 = 17; const E_TAMANO: u8 = 18; const E_TIEMPO: u8 = 19; const E_NUMERO_LARGO: u8 = 20;

#[derive(Clone, Copy)]
struct Marco { sim: i16, tiene_clave: bool, clave_n: u8, n: u32, mascara: u64, clave: [u8; CLAVE_MAX] }   // un simbolo de pila + sus registros
#[derive(Clone, Copy)]
struct ErrorV { ruta: [u8; RUTA_MAX], ruta_n: usize, codigo: u8, con_pos: bool, linea: u32, columna: u32, byte: u64 }
pub struct Dpda {
    // lexer
    afd: u8, lq: usize, linea: u32, columna: u32, pos: u64, ini_linea: u32, ini_columna: u32, ini_pos: u64,
    buf: [u8; BUF_MAX], buf_n: usize, buf_des: bool, no_coincide: bool, u8_malo: bool, num_des: bool,
    cps: u32, hex: u32, alto: u32, u8_faltan: u8, u8_lo: u8, u8_hi: u8, lit: u8,
    num: [u8; NUM_MAX], num_n: usize, valor: f64, tipo_tok: i64,
    // automata de pila
    q: usize, tope: usize, max_prof: usize, pila_max: u32, parar: bool, terminado: bool, mal_formado: bool, limite: u8,
    violaciones: u64, costo: u64, pasos: u64,
    n_err: usize, errores: [ErrorV; ERR_MAX],
    pila: [Marco; PILA_MAX],                                 // pila de tamano FIJO
}
const MARCO0: Marco = Marco { sim: 0, tiene_clave: false, clave_n: 0, n: 0, mascara: 0, clave: [0; CLAVE_MAX] };
const ERROR0: ErrorV = ErrorV { ruta: [0; RUTA_MAX], ruta_n: 0, codigo: 0, con_pos: false, linea: 0, columna: 0, byte: 0 };

fn hexval(b: u8) -> u32 { if b <= b'9' { (b - b'0') as u32 } else { ((b | 32) - b'a') as u32 + 10 } }

impl Dpda {
    pub fn nuevo(max_prof: u32, parar: bool) -> Dpda {
        let mp = if max_prof == 0 || max_prof as usize > PILA_MAX { PILA_MAX } else { max_prof as usize };
        Dpda { afd: A_NADA, lq: 0, linea: 1, columna: 1, pos: 0, ini_linea: 0, ini_columna: 0, ini_pos: 0,
               buf: [0; BUF_MAX], buf_n: 0, buf_des: false, no_coincide: false, u8_malo: false, num_des: false,
               cps: 0, hex: 0, alto: 0, u8_faltan: 0, u8_lo: 0, u8_hi: 0, lit: 0,
               num: [0; NUM_MAX], num_n: 0, valor: 0.0, tipo_tok: 0,
               q: 0, tope: 0, max_prof: mp, pila_max: 1, parar, terminado: false, mal_formado: false, limite: 0,
               violaciones: 0, costo: 0, pasos: 0, n_err: 0, errores: [ERROR0; ERR_MAX], pila: [MARCO0; PILA_MAX] }
    }
    // ruta JSON Pointer del valor actual, leida de la pila
    fn ruta_de(&self, sin_tope: bool, o: &mut [u8; RUTA_MAX]) -> usize {
        let mut k = 0usize;
        let fin = self.tope - if sin_tope && self.tope > 0 { 1 } else { 0 };
        let mut i = 1;
        while i <= fin && k + 80 < RUTA_MAX {
            let m = &self.pila[i];
            if ES_ARR[m.sim as usize] != 0 {
                if m.n > 0 {
                    o[k] = b'/'; k += 1;
                    let mut d = [0u8; 12]; let mut x = m.n - 1; let mut n = 0;
                    loop { d[n] = b'0' + (x % 10) as u8; n += 1; x /= 10; if x == 0 { break; } }
                    while n > 0 { n -= 1; o[k] = d[n]; k += 1; }
                }
            } else if m.tiene_clave {
                o[k] = b'/'; k += 1;
                let mut j = 0;
                while j < m.clave_n as usize && k + 4 < RUTA_MAX {
                    let c = m.clave[j];
                    if c == b'~' { o[k] = b'~'; o[k + 1] = b'0'; k += 2; } else if c == b'/' { o[k] = b'~'; o[k + 1] = b'1'; k += 2; }
                    else { o[k] = c; k += 1; }
                    j += 1;
                }
            }
            i += 1;
        }
        if k == 0 { o[0] = b'/'; k = 1; }
        k
    }
    fn violar(&mut self, codigo: u8, sin_tope: bool, con_pos: bool, lin: u32, col: u32, byte: u64) {
        self.violaciones += 1;
        if self.n_err < ERR_MAX {
            let mut r = [0u8; RUTA_MAX];
            let n = self.ruta_de(sin_tope, &mut r);
            self.errores[self.n_err] = ErrorV { ruta: r, ruta_n: n, codigo, con_pos, linea: lin, columna: col, byte };
            self.n_err += 1;
        }
    }
    fn malformado(&mut self, codigo: u8, con_pos: bool, lin: u32, col: u32, byte: u64) {
        self.mal_formado = true; self.terminado = true;
        self.violar(codigo, false, con_pos, lin, col, byte);
    }
    fn parado(&self) -> bool { self.terminado || (self.parar && self.violaciones > 0) }

    fn igual_const(&self, c: &Konst, tk: usize) -> bool {
        if tk == T_LITERAL { return (c.tipo == 0 && self.lit == b'n') || (c.tipo == 1 && self.lit == b't') || (c.tipo == 2 && self.lit == b'f'); }
        if tk == T_NUMERO { return c.tipo == 3 && c.d == self.valor; }
        c.tipo == 4 && !self.buf_des && !self.no_coincide && self.buf_n == c.s_n as usize
            && self.buf[..self.buf_n] == BYTES[c.s_ini as usize..(c.s_ini + c.s_n) as usize]
    }
    // una comprobacion (guarda) de la fila: true si se cumple
    fn guarda(&self, g: &Guarda, tk: usize) -> bool {
        let t = &self.pila[self.tope];
        match g.op {
            G_TIPO => (g.a & self.tipo_tok) != 0,
            G_NUNCA | G_PROHIBIDA => false,
            G_ENUM | G_CONST => {
                if tk == T_LLAVE_A || tk == T_CORCH_A { return g.a != 0; }
                let mut i = 0;
                while i < g.c_n { if self.igual_const(&CONSTS[(g.c_ini + i) as usize], tk) { return true; } i += 1; }
                false
            }
            G_MIN => self.valor >= g.d,
            G_MAX => self.valor <= g.d,
            G_MINLEN => self.cps as i64 >= g.a,
            G_MAXLEN => self.cps as i64 <= g.a,
            G_DUP => g.a < 0 || (t.mascara >> g.a) & 1 == 0,
            G_REQ => (t.mascara & g.a as u64) == g.a as u64,
            G_MINITEMS => t.n as i64 >= g.a,
            G_MAXITEMS => t.n as i64 <= g.a,
            _ => true,
        }
    }
    // delta(q, a, X): tabla densa por (estado, simbolo) y lista corta por tope de pila
    fn buscar(q: usize, a: usize, x: i16, comodin: bool) -> Option<usize> {
        let mut libre = None;
        let mut i = ALT_INI[q * NA + a] as usize;
        let fin = ALT_INI[q * NA + a + 1] as usize;
        while i < fin {
            if ALT_TOPE[i] == x { return Some(ALT_FILA[i] as usize); }
            if ALT_TOPE[i] < 0 && comodin { libre = Some(ALT_FILA[i] as usize); }
            i += 1;
        }
        libre
    }
    fn ejecutar(&mut self, fi: usize, a: usize, tk: usize, lin: u32, col: u32, byte: u64) {
        let f = FILAS[fi];
        let cierre = f.pila == 1;
        let mut costo: u64 = if a != S_EPS { 1 } else { 0 };
        if f.reg == 1 { let t = &mut self.pila[self.tope]; if t.n < u32::MAX { t.n += 1; } }
        else if f.reg >= 2 {
            let n = if self.buf_n < CLAVE_MAX - 1 { self.buf_n } else { CLAVE_MAX - 1 };
            let t = &mut self.pila[self.tope];
            t.clave[..n].copy_from_slice(&self.buf[..n]); t.clave_n = n as u8; t.tiene_clave = true;
        }
        let mut i = 0;
        while i < f.g_n as i32 {                               // comprobaciones: de la mas barata a la mas cara
            let g = GUARDAS[(f.g_ini + i) as usize];
            costo += g.costo as u64;
            if !self.guarda(&g, tk) {
                self.violar(g.op, cierre, true, lin, col, byte);
                if g.op == G_TIPO || g.op == G_NUNCA || self.parar { break; }      // fallo temprano
            }
            i += 1;
        }
        self.costo += costo;
        if f.reg == 2 { self.pila[self.tope].mascara |= 1u64 << f.reg_arg; }
        if f.pila == 1 { self.tope -= 1; }
        else if f.pila == 2 {
            if self.tope + 1 >= self.max_prof { self.limite = E_PROFUNDIDAD; self.malformado(E_PROFUNDIDAD, true, lin, col, byte); return; }
            self.tope += 1;
            self.pila[self.tope] = MARCO0; self.pila[self.tope].sim = f.push;
            if self.tope as u32 + 1 > self.pila_max { self.pila_max = self.tope as u32 + 1; }
        }
        self.q = f.dest as usize; self.pasos += 1;
    }
    // un token llega al automata
    fn paso(&mut self, tk: usize, lin: u32, col: u32, byte: u64) {
        if self.parado() { return; }
        if self.q == Q_F { self.malformado(E_SOBRA, true, lin, col, byte); return; }
        let mut a = tk;
        if tk == T_CADENA && ES_CLAVE[self.q] != 0 {           // la cadena es una clave: cual?
            a = S_OTRA;
            if !self.buf_des && !self.no_coincide {
                let mut i = CLV_INI[self.q] as usize;
                while i < CLV_INI[self.q + 1] as usize {
                    let c = CLAVES[i];
                    if c.s_n as usize == self.buf_n && self.buf[..self.buf_n] == BYTES[c.s_ini as usize..(c.s_ini + c.s_n) as usize] { a = c.sim as usize; break; }
                    i += 1;
                }
            }
        }
        match Dpda::buscar(self.q, a, self.pila[self.tope].sim, true) {
            None => { self.malformado(E_SINTAXIS, true, lin, col, byte); return; }
            Some(fi) => self.ejecutar(fi, a, tk, lin, col, byte),
        }
        while !self.terminado {                                // transiciones epsilon (estado R)
            match Dpda::buscar(self.q, S_EPS, self.pila[self.tope].sim, false) {
                Some(fi) => self.ejecutar(fi, S_EPS, tk, lin, col, byte),
                None => break,
            }
        }
    }

    // ---- lexer: los AFD de la Fase 1, byte a byte ----
    fn hundir(&mut self, b: u8) { if self.buf_n < BUF_MAX { self.buf[self.buf_n] = b; self.buf_n += 1; } else { self.buf_des = true; } }
    fn hundir_cp(&mut self, c: u32) {
        if c < 0x80 { self.hundir(c as u8); }
        else if c < 0x800 { self.hundir((0xC0 | (c >> 6)) as u8); self.hundir((0x80 | (c & 63)) as u8); }
        else if c < 0x10000 { self.hundir((0xE0 | (c >> 12)) as u8); self.hundir((0x80 | ((c >> 6) & 63)) as u8); self.hundir((0x80 | (c & 63)) as u8); }
        else { self.hundir((0xF0 | (c >> 18)) as u8); self.hundir((0x80 | ((c >> 12) & 63)) as u8); self.hundir((0x80 | ((c >> 6) & 63)) as u8); self.hundir((0x80 | (c & 63)) as u8); }
    }
    fn soltar_alto(&mut self) { if self.alto != 0 { self.alto = 0; self.no_coincide = true; } }
    fn unidad(&mut self, u: u32) {                             // llego un \uXXXX completo
        if self.alto != 0 && (0xDC00..=0xDFFF).contains(&u) { let c = 0x10000 + ((self.alto - 0xD800) << 10) + (u - 0xDC00); self.alto = 0; self.hundir_cp(c); return; }
        self.soltar_alto(); self.cps += 1;
        if (0xD800..=0xDBFF).contains(&u) { self.alto = u; }
        else if (0xDC00..=0xDFFF).contains(&u) { self.no_coincide = true; }
        else { self.hundir_cp(u); }
    }
    fn utf8(&mut self, b: u8) {                                // AFD de UTF-8 bien formado
        if self.u8_faltan == 0 {
            if b < 0x80 { return; }
            self.u8_lo = 0x80; self.u8_hi = 0xBF;
            if (0xC2..=0xDF).contains(&b) { self.u8_faltan = 1; }
            else if b == 0xE0 { self.u8_faltan = 2; self.u8_lo = 0xA0; }
            else if b == 0xED { self.u8_faltan = 2; self.u8_hi = 0x9F; }
            else if (0xE1..=0xEF).contains(&b) { self.u8_faltan = 2; }
            else if b == 0xF0 { self.u8_faltan = 3; self.u8_lo = 0x90; }
            else if b == 0xF4 { self.u8_faltan = 3; self.u8_hi = 0x8F; }
            else if (0xF1..=0xF3).contains(&b) { self.u8_faltan = 3; }
            else { self.u8_malo = true; }
        } else if b < self.u8_lo || b > self.u8_hi { self.u8_malo = true; self.u8_faltan = 0; }
        else { self.u8_faltan -= 1; self.u8_lo = 0x80; self.u8_hi = 0xBF; }
    }
    fn accion(&mut self, b: u8, cl: usize) {                   // lo que se guarda del token mientras se lee
        if self.afd == A_NUM { if self.num_n < NUM_MAX - 1 { self.num[self.num_n] = b; self.num_n += 1; } else { self.num_des = true; } return; }
        if self.afd == A_LIT { if self.lq == 0 { self.lit = b; } return; }
        self.utf8(b);
        if self.lq == SC_C1 {
            if cl == KC_COMILLA { self.soltar_alto(); }
            else if cl != KC_BARRA { self.soltar_alto(); if (b & 0xC0) != 0x80 { self.cps += 1; } self.hundir(b); }
        } else if self.lq == SC_C3 {
            if cl == KC_U { self.hex = 0; }
            else { self.soltar_alto(); self.cps += 1;
                   self.hundir(match b { b'b' => 8, b'f' => 12, b'n' => 10, b'r' => 13, b't' => 9, _ => b }); }
        } else if self.lq >= SC_C4 && self.lq <= SC_C7 {
            self.hex = self.hex * 16 + hexval(b);
            if self.lq == SC_C7 { let h = self.hex; self.unidad(h); }
        }
    }
    fn lexico(&mut self) { if !self.parado() { let (l, c, p) = (self.linea, self.columna, self.pos); self.malformado(E_LEXICO, true, l, c, p); } self.terminado = true; }
    fn emitir(&mut self) {
        let afd = self.afd; self.afd = A_NADA;
        let tk;
        if afd == A_CAD { if self.u8_malo || self.u8_faltan != 0 { self.lexico(); return; } tk = T_CADENA; self.tipo_tok = 1; }
        else if afd == A_NUM {
            if self.num_des { self.limite = E_NUMERO_LARGO; let (l, c, p) = (self.ini_linea, self.ini_columna, self.ini_pos); self.malformado(E_NUMERO_LARGO, true, l, c, p); return; }
            let txt = &self.num[..self.num_n];
            self.valor = core::str::from_utf8(txt).ok().and_then(|s| s.parse::<f64>().ok()).unwrap_or(0.0);
            let mut entero = !txt.iter().any(|&c| c == b'.' || c == b'e' || c == b'E');
            if !entero { entero = self.valor.is_finite() && self.valor.floor() == self.valor; }   // finito y sin decimales
            tk = T_NUMERO; self.tipo_tok = 2 | if entero { 4 } else { 0 };
        } else { tk = T_LITERAL; self.tipo_tok = if self.lit == b'n' { 16 } else { 8 }; }
        let (l, c, p) = (self.ini_linea, self.ini_columna, self.ini_pos);
        self.paso(tk, l, c, p);
    }
    fn avanzar(&mut self, b: u8) { self.pos += 1; if b == b'\n' { self.linea += 1; self.columna = 1; } else { self.columna += 1; } }
    fn un_byte(&mut self, b: u8) {
        loop {
            if self.afd == A_NADA {                              // entre tokens
                if b == b' ' || b == b'\t' || b == b'\n' || b == b'\r' { self.avanzar(b); return; }
                let s = SIMBOLO[b as usize];
                if s >= 0 {
                    let s = s as usize;
                    self.tipo_tok = if s == T_LLAVE_A { 32 } else if s == T_CORCH_A { 64 } else { 0 };
                    let (l, c, p) = (self.linea, self.columna, self.pos);
                    self.paso(s, l, c, p); self.avanzar(b); return;
                }
                if b == b'"' { self.afd = A_CAD; } else if b == b'-' || b.is_ascii_digit() { self.afd = A_NUM; }
                else if b == b't' || b == b'f' || b == b'n' { self.afd = A_LIT; } else { self.lexico(); return; }
                self.lq = 0; self.ini_linea = self.linea; self.ini_columna = self.columna; self.ini_pos = self.pos;
                self.buf_n = 0; self.buf_des = false; self.no_coincide = false; self.u8_malo = false; self.u8_faltan = 0;
                self.cps = 0; self.alto = 0; self.num_n = 0; self.num_des = false;
            }
            let (cl, sig, acepta, nosigue);
            if self.afd == A_NUM { cl = LN_CLASE[b as usize] as usize; sig = LN_TRANS[self.lq * LN_NC + cl]; acepta = LN_ACEPTA[self.lq]; nosigue = LN_NOSIGUE[b as usize]; }
            else if self.afd == A_CAD { cl = LC_CLASE[b as usize] as usize; sig = LC_TRANS[self.lq * LC_NC + cl]; acepta = LC_ACEPTA[self.lq]; nosigue = LC_NOSIGUE[b as usize]; }
            else { cl = LL_CLASE[b as usize] as usize; sig = LL_TRANS[self.lq * LL_NC + cl]; acepta = LL_ACEPTA[self.lq]; nosigue = LL_NOSIGUE[b as usize]; }
            if sig >= 0 { self.accion(b, cl); self.lq = sig as usize; self.avanzar(b); return; }     // hay flecha
            if acepta == 0 || nosigue != 0 { self.lexico(); return; }
            self.emitir();                                       // token completo: va al automata
            if self.parado() { return; }
        }                                                        // y se vuelve a mirar el mismo byte
    }

    pub fn alimentar(&mut self, d: &[u8]) -> bool {             // un bloque de bytes; true = ya no hace falta mas
        for &b in d { if self.parado() { return true; } self.un_byte(b); }
        self.parado()
    }
    pub fn cortar(&mut self, por_tiempo: bool) {                // limite de tamano o de tiempo superado
        if self.parado() { return; }
        self.limite = if por_tiempo { E_TIEMPO } else { E_TAMANO };
        let l = self.limite; self.malformado(l, false, 0, 0, 0);
    }
    pub fn terminar(&mut self) -> i32 {                         // 0 valido, 1 invalido, 2 mal formado
        if !self.parado() && self.afd != A_NADA {
            let acepta = if self.afd == A_NUM { LN_ACEPTA[self.lq] } else if self.afd == A_CAD { LC_ACEPTA[self.lq] } else { LL_ACEPTA[self.lq] };
            if acepta == 0 { self.lexico(); } else { self.emitir(); }
        }
        if !self.parado() && self.q != Q_F { self.malformado(E_INCOMPLETO, false, 0, 0, 0); }
        if self.violaciones == 0 { 0 } else if self.mal_formado { 2 } else { 1 }
    }
    pub fn reporte(&self, salida: &mut [u8]) -> usize {         // el resultado como una linea JSON
        let mut s = Sal { p: salida, n: 0 };
        s.pon(b"{\"valido\":"); s.pon(if self.violaciones > 0 { b"false" } else { b"true" });
        s.pon(b",\"mal_formado\":"); s.pon(if self.mal_formado { b"true" } else { b"false" });
        s.pon(b",\"limite\":"); if self.limite != 0 { s.pon(b"\""); s.pon(NOMBRE_ERR[self.limite as usize].as_bytes()); s.pon(b"\""); } else { s.pon(b"null"); }
        s.pon(b",\"violaciones\":"); s.pon_u(self.violaciones); s.pon(b",\"costo\":"); s.pon_u(self.costo);
        s.pon(b",\"pasos\":"); s.pon_u(self.pasos); s.pon(b",\"pila_max\":"); s.pon_u(self.pila_max as u64);
        s.pon(b",\"bytes\":"); s.pon_u(self.pos); s.pon(b",\"errores\":[");
        for i in 0..self.n_err {
            let e = &self.errores[i];
            s.pon(if i > 0 { b",{\"ruta\":\"" } else { b"{\"ruta\":\"" }); s.pon_esc(&e.ruta[..e.ruta_n]);
            s.pon(b"\",\"codigo\":\""); s.pon(NOMBRE_ERR[e.codigo as usize].as_bytes()); s.pon(b"\"");
            if e.con_pos { s.pon(b",\"linea\":"); s.pon_u(e.linea as u64); s.pon(b",\"columna\":"); s.pon_u(e.columna as u64); s.pon(b",\"byte\":"); s.pon_u(e.byte); }
            else { s.pon(b",\"linea\":null,\"columna\":null,\"byte\":null"); }
            s.pon(b"}");
        }
        s.pon(b"]}");
        s.n
    }
}
struct Sal<'a> { p: &'a mut [u8], n: usize }
impl<'a> Sal<'a> {
    fn pon(&mut self, t: &[u8]) { for &c in t { if self.n < self.p.len() { self.p[self.n] = c; self.n += 1; } } }
    fn pon_u(&mut self, mut x: u64) { let mut d = [0u8; 20]; let mut n = 0; loop { d[n] = b'0' + (x % 10) as u8; n += 1; x /= 10; if x == 0 { break; } } while n > 0 { n -= 1; let c = d[n]; self.pon(&[c]); } }
    fn pon_esc(&mut self, t: &[u8]) {
        for &c in t {
            if c == b'"' || c == b'\\' { self.pon(&[b'\\', c]); }
            else if c < 0x20 { let h = b"0123456789abcdef"; self.pon(&[b'\\', b'u', b'0', b'0', h[(c >> 4) as usize], h[(c & 15) as usize]]); }
            else { self.pon(&[c]); }
        }
    }
}

// ===== API C-ABI (FFI): la memoria la pone quien llama =====
#[no_mangle] pub extern "C" fn dpda_tamano() -> usize { core::mem::size_of::<Dpda>() }
#[no_mangle] pub unsafe extern "C" fn dpda_iniciar(v: *mut Dpda, max_prof: u32, parar: i32) { core::ptr::write(v, Dpda::nuevo(max_prof, parar != 0)); }
#[no_mangle] pub unsafe extern "C" fn dpda_alimentar(v: *mut Dpda, d: *const u8, n: usize) -> i32 { (*v).alimentar(core::slice::from_raw_parts(d, n)) as i32 }
#[no_mangle] pub unsafe extern "C" fn dpda_cortar(v: *mut Dpda, por_tiempo: i32) { (*v).cortar(por_tiempo != 0) }
#[no_mangle] pub unsafe extern "C" fn dpda_terminar(v: *mut Dpda) -> i32 { (*v).terminar() }
#[no_mangle] pub unsafe extern "C" fn dpda_reporte(v: *const Dpda, salida: *mut u8, cap: usize) -> usize {
    if cap == 0 { return 0; }
    let s = core::slice::from_raw_parts_mut(salida, cap);
    let n = (*v).reporte(&mut s[..cap - 1]); s[n] = 0; n
}
#[no_mangle] pub extern "C" fn dpda_estados() -> u32 { NQ as u32 }
#[no_mangle] pub extern "C" fn dpda_transiciones() -> u32 { NFILAS as u32 }

// ===== programa de linea de comandos (con instrumentacion de la Fase 6) =====
mod cuenta {                                                   // cuenta las asignaciones de memoria
    use std::alloc::{GlobalAlloc, Layout, System};
    use std::sync::atomic::{AtomicU64, Ordering};
    pub static N: AtomicU64 = AtomicU64::new(0);
    pub struct Contador;
    unsafe impl GlobalAlloc for Contador {
        unsafe fn alloc(&self, l: Layout) -> *mut u8 { N.fetch_add(1, Ordering::Relaxed); System.alloc(l) }
        unsafe fn dealloc(&self, p: *mut u8, l: Layout) { System.dealloc(p, l) }
    }
    pub fn total() -> u64 { N.load(Ordering::Relaxed) }
}
#[global_allocator] static ASIGNADOR: cuenta::Contador = cuenta::Contador;

fn ciclos() -> u64 {
    #[cfg(target_arch = "x86_64")] { return unsafe { core::arch::x86_64::_rdtsc() }; }
    #[cfg(not(target_arch = "x86_64"))] { return 0; }
}
const LAT_MAX: usize = 65536;
static mut LAT: [u64; LAT_MAX] = [0; LAT_MAX];
static mut ENT: [u8; 65536] = [0; 65536];
static mut SAL: [u8; ERR_MAX * (RUTA_MAX * 6 + 160) + 512] = [0; ERR_MAX * (RUTA_MAX * 6 + 160) + 512];

fn main() {
    use std::io::{Read, Write};
    use std::time::Instant;
    let (mut parar, mut lote, mut metricas, mut silencio) = (false, false, false, false);
    let (mut prof, mut max_bytes, mut max_ms, mut bloque) = (0u32, 0u64, 0u64, 65536usize);
    let mut args = std::env::args().skip(1);
    while let Some(a) = args.next() {
        match a.as_str() {
            "--parar" => parar = true, "--lote" => lote = true, "--metricas" => metricas = true, "--silencio" => silencio = true,
            "--prof" => prof = args.next().and_then(|x| x.parse().ok()).unwrap_or(0),
            "--max-bytes" => max_bytes = args.next().and_then(|x| x.parse().ok()).unwrap_or(0),
            "--max-ms" => max_ms = args.next().and_then(|x| x.parse().ok()).unwrap_or(0),
            "--bloque" => { bloque = args.next().and_then(|x| x.parse().ok()).unwrap_or(65536); if bloque < 1 || bloque > 65536 { bloque = 65536; } }
            _ => { eprintln!("uso: validador_rs [--parar] [--prof N] [--max-bytes N] [--max-ms N] [--bloque N] [--lote] [--metricas] [--silencio] < documento"); std::process::exit(3); }
        }
    }
    let ent = unsafe { &mut *core::ptr::addr_of_mut!(ENT) };
    let sal = unsafe { &mut *core::ptr::addr_of_mut!(SAL) };
    let lat = unsafe { &mut *core::ptr::addr_of_mut!(LAT) };
    let stdin = std::io::stdin(); let mut entrada = stdin.lock();
    let stdout = std::io::stdout(); let mut salida = stdout.lock();
    let mut v = Dpda::nuevo(prof, parar);
    let (mut t_ns, mut t_cic, mut total, mut n_docs, mut doc_bytes, mut doc_ns) = (0u64, 0u64, 0u64, 0u64, 0u64, 0u64);
    let mut cnt = [0u64; 3]; let mut n_lat = 0usize; let mut peor = 0i32; let mut abierto = false;
    let mut doc_t0 = Instant::now();
    let m0 = cuenta::total(); let mut asignaciones = 0u64;
    loop {
        let n = match entrada.read(&mut ent[..bloque]) { Ok(n) => n, Err(_) => 0 };
        let fin = n == 0;
        let mut a = 0usize;
        while a < n || fin {
            let mut b = a; let mut cerrar = fin;
            if !fin {
                if lote { while b < n && ent[b] != 0x1E { b += 1; } cerrar = b < n; } else { b = n; }
                if !abierto { abierto = true; doc_t0 = Instant::now(); }
                let (t0, c0, k0) = (Instant::now(), ciclos(), cuenta::total());
                if max_bytes != 0 && doc_bytes + (b - a) as u64 > max_bytes { v.alimentar(&ent[a..a + (max_bytes - doc_bytes) as usize]); v.cortar(false); }
                else { v.alimentar(&ent[a..b]); }
                asignaciones += cuenta::total() - k0;
                doc_bytes += (b - a) as u64; total += (b - a) as u64;
                t_cic += ciclos().wrapping_sub(c0); let d = t0.elapsed().as_nanos() as u64; t_ns += d; doc_ns += d;
                if max_ms != 0 && doc_t0.elapsed().as_millis() as u64 > max_ms { v.cortar(true); }
            }
            if cerrar && (abierto || !lote) {                    // fin de un documento
                let (t0, c0, k0) = (Instant::now(), ciclos(), cuenta::total());
                let r = v.terminar();
                asignaciones += cuenta::total() - k0;
                t_cic += ciclos().wrapping_sub(c0); let d = t0.elapsed().as_nanos() as u64; t_ns += d; doc_ns += d;
                cnt[r as usize] += 1; n_docs += 1; if r > peor { peor = r; }
                if n_lat < LAT_MAX { lat[n_lat] = doc_ns; n_lat += 1; }
                if !silencio { let k = v.reporte(&mut sal[..]); let _ = salida.write_all(&sal[..k]); let _ = salida.write_all(b"\n"); }
                v = Dpda::nuevo(prof, parar); doc_bytes = 0; doc_ns = 0; abierto = false;
            }
            if fin { break; }
            a = b + if cerrar { 1 } else { 0 };
        }
        if fin { break; }
    }
    let _ = salida.flush();
    let _ = m0;
    if metricas {
        lat[..n_lat].sort_unstable();
        let mb_s = if t_ns > 0 { total as f64 / 1048576.0 / (t_ns as f64 / 1e9) } else { 0.0 };
        let cpb = if total > 0 && t_cic > 0 { t_cic as f64 / total as f64 } else { -1.0 };
        eprintln!("{{\"docs\":{},\"validos\":{},\"invalidos\":{},\"mal_formados\":{},\"bytes\":{},\"ns\":{},\"mb_s\":{:.2},\"ciclos_byte\":{:.2},\"asignaciones\":{},\"mem_validador\":{},\"estados\":{},\"transiciones\":{},\"lat_p50_ns\":{},\"lat_p99_ns\":{},\"lat_max_ns\":{}}}",
                  n_docs, cnt[0], cnt[1], cnt[2], total, t_ns, mb_s, cpb, asignaciones, core::mem::size_of::<Dpda>(), NQ, NFILAS,
                  if n_lat > 0 { lat[n_lat / 2] } else { 0 }, if n_lat > 0 { lat[(n_lat * 99) / 100] } else { 0 }, if n_lat > 0 { lat[n_lat - 1] } else { 0 });
    }
    std::process::exit(peor);
}
