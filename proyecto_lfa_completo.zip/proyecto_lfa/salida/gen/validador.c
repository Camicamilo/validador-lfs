/* validador.c - GENERADO por generador_v1.py (Fase 5). No editar a mano.
   Validador nativo de UN esquema: automata de pila determinista ponderado.
   Compilar:  gcc -O2 -o validador validador.c -lm
   Biblioteca (FFI): gcc -O2 -shared -fPIC -DSIN_MAIN -o libvalidador.so validador.c -lm */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>
#define ERR_MAX 16      /* errores que se guardan con su ruta (se cuentan todos) */
#define RUTA_MAX 256
#define CLAVE_MAX 64
#define NUM_MAX 512
/* ===== TABLAS generadas a partir del esquema (son DATOS, no logica) ===== */
/* DPDA: 22 estados, 69 filas de delta, 5 simbolos de pila, 13 simbolos de entrada */
/* estados: 0=V0 1=B2 2=B* 3=C0.? 4=C0.id 5=C0.tags 6=C*.? 7=E2 8=E* 9=G2 10=G* 11=K0 12=K* 13=M0 14=M* 15=N0 16=N* 17=R 18=V1 19=V2 20=V* 21=qF */
/* pila:    0=Z0 1=A2 2=A* 3=O0 4=O* */
#ifndef PILA_MAX
#define PILA_MAX 1024   /* profundidad maxima de la pila */
#endif
#define BUF_MAX 64
#define NQ 22
#define NA 13
#define NFILAS 69
#define Q_F 21
#define S_OTRA 11
#define S_EPS 12
#define SC_C1 1
#define SC_C3 3
#define SC_C4 4
#define SC_C7 7
#define KC_COMILLA 2
#define KC_BARRA 0
#define KC_U 6
#define LN_NC 7
static const uint8_t LN_CLASE[256] = {
  6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
  6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 3, 6, 4, 5, 6, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 6, 6, 6, 6, 6,
  6, 6, 6, 6, 6, 2, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
  6, 6, 6, 6, 6, 2, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
  6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
  6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
  6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
  6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6};
static const int8_t LN_TRANS[] = {
  2, 3, -1, -1, 1, -1, -1, 2, 3, -1, -1, -1, -1, -1, -1, -1, 6, -1, -1, 4, -1, 3, 3, 6, -1, -1, 4, -1, 5, 5, -1, -1,
  -1, -1, -1, 5, 5, 6, -1, -1, -1, -1, 8, 8, -1, 7, 7, -1, -1, 8, 8, -1, -1, -1, -1, -1, 8, 8, -1, -1, -1, -1, -1};
static const uint8_t LN_ACEPTA[] = {0, 0, 1, 1, 0, 1, 0, 0, 1};
static const uint8_t LN_NOSIGUE[256] = {
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#define LC_NC 8
static const uint8_t LC_CLASE[256] = {
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
  5, 5, 2, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5,
  5, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 0, 5, 5, 5,
  5, 4, 1, 4, 4, 4, 1, 5, 5, 5, 5, 5, 5, 5, 3, 5, 5, 5, 3, 5, 3, 6, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
  5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
  5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
  5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
  5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5};
static const int8_t LC_TRANS[] = {
  -1, -1, 1, -1, -1, -1, -1, -1, 3, 1, 2, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, -1, -1, 4, -1,
  -1, 5, -1, -1, 5, -1, -1, -1, -1, 6, -1, -1, 6, -1, -1, -1, -1, 7, -1, -1, 7, -1, -1, -1, -1, 1, -1, -1, 1, -1, -1, -1};
static const uint8_t LC_ACEPTA[] = {0, 0, 1, 0, 0, 0, 0, 0};
static const uint8_t LC_NOSIGUE[256] = {
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#define LL_NC 10
static const uint8_t LL_CLASE[256] = {
  9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
  9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
  9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
  9, 0, 9, 9, 9, 1, 2, 9, 9, 9, 9, 9, 3, 9, 4, 9, 9, 9, 5, 6, 7, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
  9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
  9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
  9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9,
  9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9};
static const int8_t LL_TRANS[] = {
  -1, -1, 5, -1, 10, -1, -1, 1, -1, -1, -1, -1, -1, -1, -1, 2, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 3, -1, -1, 4,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 6, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 7,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 8, -1, -1, -1, -1, 9, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 11, -1, -1, -1, -1, 12, -1, -1, -1, -1, -1, -1, -1, -1, -1, 13, -1, -1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
static const uint8_t LL_ACEPTA[] = {0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1};
static const uint8_t LL_NOSIGUE[256] = {
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
  0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1,
  0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
static const int8_t SIMBOLO[256] = {
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 5, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 4, -1, -1, -1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 2, -1, 3, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, -1, 1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
static const int32_t ALT_INI[] = {
  0, 1, 1, 2, 2, 2, 2, 3, 4, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 7,
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9,
  9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 11, 11, 11,
  11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12,
  12, 12, 12, 13, 13, 13, 13, 13, 13, 13, 13, 13, 14, 14, 15, 16, 16, 16, 17, 18,
  19, 19, 19, 19, 19, 20, 20, 21, 22, 22, 22, 23, 24, 25, 25, 25, 25, 25, 26, 26,
  27, 27, 27, 27, 28, 29, 30, 30, 30, 30, 30, 31, 31, 32, 32, 32, 32, 33, 34, 35,
  35, 35, 35, 35, 35, 36, 36, 36, 36, 36, 36, 36, 36, 37, 38, 39, 39, 39, 40, 40,
  40, 40, 40, 40, 40, 40, 40, 40, 41, 41, 41, 42, 42, 42, 42, 43, 43, 43, 43, 43,
  43, 43, 43, 43, 44, 44, 44, 44, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45,
  45, 45, 45, 45, 45, 46, 47, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48,
  49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 49, 54, 55, 55, 56, 56, 56,
  56, 57, 58, 59, 59, 59, 59, 59, 60, 60, 61, 61, 61, 61, 62, 63, 64, 64, 64, 64,
  64, 65, 65, 66, 66, 66, 66, 67, 68, 69, 69, 69, 69, 69, 69, 69, 69, 69, 69, 69,
  69, 69, 69, 69, 69, 69, 69};
static const int16_t ALT_TOPE[] = {
  -1, -1, -1, -1, -1, 1, 1, 2, 2, 3, 3, 3, 4, 1, 1, 1, 1, 1, 1, 2,
  2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 3, 3, 3, 4,
  4, 3, 3, 4, 4, 3, 3, 3, 4, 0, 1, 2, 3, 4, -1, -1, -1, -1, -1, -1,
  -1, -1, -1, -1, -1, -1, -1, -1, -1};
static const int16_t ALT_FILA[] = {
  0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
  20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39,
  40, 41, 42, 43, 44, 45, 46, 47, 48, 53, 50, 49, 52, 51, 54, 55, 56, 57, 58, 59,
  60, 61, 62, 63, 64, 65, 66, 67, 68};
typedef struct { int16_t dest; uint8_t pila; int16_t push; uint8_t reg; int8_t reg_arg; int32_t g_ini; uint8_t g_n; } Fila;
static const Fila FILAS[] = {
  {11,2,3,0,0,0,1}, {8,2,2,0,0,1,1}, {17,0,0,0,0,2,1}, {17,0,0,0,0,3,1}, {17,0,0,0,0,4,1}, {17,1,0,0,0,5,0},
  {9,0,0,0,0,5,0}, {17,1,0,0,0,5,0}, {10,0,0,0,0,5,0}, {20,0,0,0,0,5,0}, {18,0,0,0,0,5,0}, {19,0,0,0,0,5,0},
  {20,0,0,0,0,5,0}, {12,2,4,1,0,5,1}, {8,2,2,1,0,6,1}, {17,1,0,0,0,7,0}, {1,0,0,1,0,7,1}, {1,0,0,1,0,8,1},
  {1,0,0,1,0,9,1}, {12,2,4,1,0,10,0}, {8,2,2,1,0,10,0}, {17,1,0,0,0,10,0}, {2,0,0,1,0,10,0}, {2,0,0,1,0,10,0},
  {2,0,0,1,0,10,0}, {12,2,4,1,0,10,1}, {8,2,2,1,0,11,1}, {1,0,0,1,0,12,1}, {1,0,0,1,0,13,1}, {1,0,0,1,0,14,1},
  {12,2,4,1,0,15,0}, {8,2,2,1,0,15,0}, {2,0,0,1,0,15,0}, {2,0,0,1,0,15,0}, {2,0,0,1,0,15,0}, {17,1,0,0,0,15,1},
  {4,0,0,2,0,16,1}, {5,0,0,2,1,17,1}, {3,0,0,3,0,18,1}, {17,1,0,0,0,19,0}, {6,0,0,3,0,19,1}, {17,1,0,0,0,20,1},
  {15,0,0,0,0,21,0}, {17,1,0,0,0,21,0}, {16,0,0,0,0,21,0}, {4,0,0,2,0,21,1}, {5,0,0,2,1,22,1}, {3,0,0,3,0,23,1},
  {6,0,0,3,0,24,1}, {2,0,0,0,0,25,0}, {1,0,0,0,0,25,0}, {14,0,0,0,0,25,0}, {13,0,0,0,0,25,0}, {21,0,0,0,0,25,0},
  {12,2,4,0,0,25,1}, {8,2,2,0,0,26,1}, {17,0,0,0,0,27,1}, {17,0,0,0,0,28,1}, {17,0,0,0,0,29,1}, {12,2,4,0,0,30,1},
  {7,2,1,0,0,31,1}, {17,0,0,0,0,32,1}, {17,0,0,0,0,33,1}, {17,0,0,0,0,34,1}, {12,2,4,0,0,35,0}, {8,2,2,0,0,35,0},
  {17,0,0,0,0,35,0}, {17,0,0,0,0,35,0}, {17,0,0,0,0,35,0}};
typedef struct { uint8_t op; uint32_t costo; int64_t a; double d; int32_t c_ini, c_n; } Guarda;
static const Guarda GUARDAS[] = {
  {0,1,(int64_t)UINT64_C(32),0.0,0,0}, {0,1,(int64_t)UINT64_C(32),0.0,0,0}, {0,1,(int64_t)UINT64_C(32),0.0,0,0}, {0,1,(int64_t)UINT64_C(32),0.0,0,0},
  {0,1,(int64_t)UINT64_C(32),0.0,0,0}, {0,1,(int64_t)UINT64_C(1),0.0,0,0}, {0,1,(int64_t)UINT64_C(1),0.0,0,0}, {0,1,(int64_t)UINT64_C(1),0.0,0,0},
  {0,1,(int64_t)UINT64_C(1),0.0,0,0}, {0,1,(int64_t)UINT64_C(1),0.0,0,0}, {0,1,(int64_t)UINT64_C(1),0.0,0,0}, {0,1,(int64_t)UINT64_C(1),0.0,0,0},
  {0,1,(int64_t)UINT64_C(1),0.0,0,0}, {0,1,(int64_t)UINT64_C(1),0.0,0,0}, {0,1,(int64_t)UINT64_C(1),0.0,0,0}, {10,1,(int64_t)UINT64_C(1),0.0,0,0},
  {8,1,(int64_t)UINT64_C(0),0.0,0,0}, {8,1,(int64_t)UINT64_C(1),0.0,0,0}, {8,1,(int64_t)UINT64_C(18446744073709551615),0.0,0,0}, {8,1,(int64_t)UINT64_C(18446744073709551615),0.0,0,0},
  {10,1,(int64_t)UINT64_C(1),0.0,0,0}, {8,1,(int64_t)UINT64_C(0),0.0,0,0}, {8,1,(int64_t)UINT64_C(1),0.0,0,0}, {8,1,(int64_t)UINT64_C(18446744073709551615),0.0,0,0},
  {8,1,(int64_t)UINT64_C(18446744073709551615),0.0,0,0}, {0,1,(int64_t)UINT64_C(4),0.0,0,0}, {0,1,(int64_t)UINT64_C(4),0.0,0,0}, {0,1,(int64_t)UINT64_C(4),0.0,0,0},
  {0,1,(int64_t)UINT64_C(4),0.0,0,0}, {0,1,(int64_t)UINT64_C(4),0.0,0,0}, {0,1,(int64_t)UINT64_C(64),0.0,0,0}, {0,1,(int64_t)UINT64_C(64),0.0,0,0},
  {0,1,(int64_t)UINT64_C(64),0.0,0,0}, {0,1,(int64_t)UINT64_C(64),0.0,0,0}, {0,1,(int64_t)UINT64_C(64),0.0,0,0}};
typedef struct { uint8_t tipo; double d; int32_t s_ini, s_n; } Const;
static const Const CONSTS[] = {
  {0,0.0,0,0}};
static const unsigned char BYTES[] = {
  105, 100, 116, 97, 103, 115, 105, 100, 116, 97, 103, 115};
static const uint8_t ES_CLAVE[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0};
static const int32_t CLV_INI[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 4, 4, 4, 4, 4, 4, 4};
typedef struct { int32_t s_ini, s_n; int16_t sim; } Clave;
static const Clave CLAVES[] = {
  {0,2,9}, {2,4,10}, {6,2,9}, {8,4,10}};
static const uint8_t ES_ARR[] = {0, 1, 1, 0, 0};
static const char *const NOMBRE_ERR[] = {"tipo", "nunca", "enum", "const", "minimum", "maximum", "minLength", "maxLength", "dup", "prohibida", "requeridos", "minItems", "maxItems", "sintaxis", "lexico", "incompleto", "sobra", "profundidad", "tamano", "tiempo", "numero_largo"};

/* ===== MOTOR (el mismo para cualquier esquema) ===== */
enum { T_LLAVE_A, T_LLAVE_C, T_CORCH_A, T_CORCH_C, T_DOSP, T_COMA, T_CADENA, T_NUMERO, T_LITERAL };
enum { A_NADA, A_NUM, A_CAD, A_LIT };
enum { G_TIPO, G_NUNCA, G_ENUM, G_CONST, G_MIN, G_MAX, G_MINLEN, G_MAXLEN, G_DUP, G_PROHIBIDA,
       G_REQ, G_MINITEMS, G_MAXITEMS, E_SINTAXIS, E_LEXICO, E_INCOMPLETO, E_SOBRA, E_PROFUNDIDAD,
       E_TAMANO, E_TIEMPO, E_NUMERO_LARGO };

typedef struct { int16_t sim; uint8_t tiene_clave, clave_n; uint32_t n; uint64_t mascara;
                 unsigned char clave[CLAVE_MAX]; } Marco;          /* un simbolo de pila + sus registros */
typedef struct { char ruta[RUTA_MAX]; uint8_t codigo, con_pos; uint32_t linea, columna; uint64_t byte; } Error;
typedef struct Dpda {
  /* lexer */
  int afd, lq; uint32_t linea, columna; uint64_t pos; uint32_t ini_linea, ini_columna; uint64_t ini_pos;
  unsigned char buf[BUF_MAX]; uint32_t buf_n; uint8_t buf_des, no_coincide, u8_malo, num_des;
  uint32_t cps, hex, alto; int u8_faltan; unsigned char u8_lo, u8_hi, lit;
  char num[NUM_MAX]; uint32_t num_n; double valor; int tipo_tok;
  /* automata de pila */
  int q; uint32_t tope, max_prof, pila_max; int parar, terminado, mal_formado, limite;
  uint64_t violaciones, costo, pasos;
  uint32_t n_err; Error errores[ERR_MAX];
  Marco pila[PILA_MAX];                                   /* pila de tamano FIJO */
} Dpda;

/* ruta JSON Pointer del valor actual, leida de la pila */
static void ruta_de(const Dpda *v, int sin_tope, char *o) {
  size_t k = 0; uint32_t fin = v->tope - ((sin_tope && v->tope > 0) ? 1 : 0), i, j;
  for (i = 1; i <= fin && k + 80 < RUTA_MAX; i++) {
    const Marco *m = &v->pila[i];
    if (ES_ARR[m->sim]) { if (m->n > 0) k += (size_t)snprintf(o + k, 16, "/%u", (unsigned)(m->n - 1)); }
    else if (m->tiene_clave) {
      o[k++] = '/';
      for (j = 0; j < m->clave_n && k + 4 < RUTA_MAX; j++) {
        unsigned char c = m->clave[j];
        if (c == '~') { o[k++] = '~'; o[k++] = '0'; } else if (c == '/') { o[k++] = '~'; o[k++] = '1'; }
        else o[k++] = (char)c;
      }
    }
  }
  if (k == 0) o[k++] = '/';
  o[k] = 0;
}
static void violar(Dpda *v, int codigo, int sin_tope, int con_pos, uint32_t lin, uint32_t col, uint64_t byte) {
  v->violaciones++;
  if (v->n_err < ERR_MAX) {
    Error *e = &v->errores[v->n_err++];
    ruta_de(v, sin_tope, e->ruta);
    e->codigo = (uint8_t)codigo; e->con_pos = (uint8_t)con_pos; e->linea = lin; e->columna = col; e->byte = byte;
  }
}
static void malformado(Dpda *v, int codigo, int con_pos, uint32_t lin, uint32_t col, uint64_t byte) {
  v->mal_formado = 1; v->terminado = 1;
  violar(v, codigo, 0, con_pos, lin, col, byte);
}
static int parado(const Dpda *v) { return v->terminado || (v->parar && v->violaciones); }

static int igual_const(const Dpda *v, const Const *c, int tk) {
  if (tk == T_LITERAL) return (c->tipo == 0 && v->lit == 'n') || (c->tipo == 1 && v->lit == 't') || (c->tipo == 2 && v->lit == 'f');
  if (tk == T_NUMERO) return c->tipo == 3 && c->d == v->valor;
  return c->tipo == 4 && !v->buf_des && !v->no_coincide && (int32_t)v->buf_n == c->s_n
         && memcmp(v->buf, BYTES + c->s_ini, v->buf_n) == 0;
}
/* una comprobacion (guarda) de la fila: devuelve 1 si se cumple */
static int guarda(const Dpda *v, const Guarda *g, int tk) {
  const Marco *t = &v->pila[v->tope]; int32_t i;
  switch (g->op) {
    case G_TIPO: return (g->a & v->tipo_tok) != 0;
    case G_NUNCA: case G_PROHIBIDA: return 0;
    case G_ENUM: case G_CONST:
      if (tk == T_LLAVE_A || tk == T_CORCH_A) return (int)g->a;
      for (i = 0; i < g->c_n; i++) if (igual_const(v, &CONSTS[g->c_ini + i], tk)) return 1;
      return 0;
    case G_MIN: return v->valor >= g->d;
    case G_MAX: return v->valor <= g->d;
    case G_MINLEN: return (int64_t)v->cps >= g->a;
    case G_MAXLEN: return (int64_t)v->cps <= g->a;
    case G_DUP: return g->a < 0 ? 1 : !((t->mascara >> g->a) & 1);
    case G_REQ: return (t->mascara & (uint64_t)g->a) == (uint64_t)g->a;
    case G_MINITEMS: return (int64_t)t->n >= g->a;
    case G_MAXITEMS: return (int64_t)t->n <= g->a;
  }
  return 1;
}
/* delta(q, a, X): tabla densa por (estado, simbolo) y lista corta por tope de pila */
static const Fila *buscar(int q, int a, int X, int comodin) {
  int32_t i; const Fila *libre = 0;
  for (i = ALT_INI[q * NA + a]; i < ALT_INI[q * NA + a + 1]; i++) {
    if (ALT_TOPE[i] == X) return &FILAS[ALT_FILA[i]];
    if (ALT_TOPE[i] < 0 && comodin) libre = &FILAS[ALT_FILA[i]];
  }
  return libre;
}
static void ejecutar(Dpda *v, const Fila *f, int a, int tk, uint32_t lin, uint32_t col, uint64_t byte) {
  Marco *t = &v->pila[v->tope]; int cierre = (f->pila == 1); uint64_t costo = (a != S_EPS) ? 1 : 0; int i;
  if (f->reg == 1) { if (t->n < 0xFFFFFFFFu) t->n++; }
  else if (f->reg >= 2) {
    t->clave_n = (uint8_t)(v->buf_n < CLAVE_MAX - 1 ? v->buf_n : CLAVE_MAX - 1);
    memcpy(t->clave, v->buf, t->clave_n); t->tiene_clave = 1;
  }
  for (i = 0; i < f->g_n; i++) {                           /* comprobaciones: de la mas barata a la mas cara */
    const Guarda *g = &GUARDAS[f->g_ini + i];
    costo += g->costo;
    if (!guarda(v, g, tk)) {
      violar(v, g->op, cierre, 1, lin, col, byte);
      if (g->op == G_TIPO || g->op == G_NUNCA || v->parar) break;      /* fallo temprano */
    }
  }
  v->costo += costo;
  if (f->reg == 2) t->mascara |= (uint64_t)1 << f->reg_arg;
  if (f->pila == 1) v->tope--;
  else if (f->pila == 2) {
    Marco *m;
    if (v->tope + 1 >= v->max_prof) { v->limite = E_PROFUNDIDAD; malformado(v, E_PROFUNDIDAD, 1, lin, col, byte); return; }
    m = &v->pila[++v->tope];
    m->sim = f->push; m->mascara = 0; m->n = 0; m->tiene_clave = 0; m->clave_n = 0;
    if (v->tope + 1 > v->pila_max) v->pila_max = v->tope + 1;
  }
  v->q = f->dest; v->pasos++;
}
/* un token llega al automata */
static void paso(Dpda *v, int tk, uint32_t lin, uint32_t col, uint64_t byte) {
  const Fila *f; int a = tk;
  if (parado(v)) return;
  if (v->q == Q_F) { malformado(v, E_SOBRA, 1, lin, col, byte); return; }
  if (tk == T_CADENA && ES_CLAVE[v->q]) {                  /* la cadena es una clave: cual? */
    int32_t i; a = S_OTRA;
    if (!v->buf_des && !v->no_coincide)
      for (i = CLV_INI[v->q]; i < CLV_INI[v->q + 1]; i++)
        if (CLAVES[i].s_n == (int32_t)v->buf_n && memcmp(v->buf, BYTES + CLAVES[i].s_ini, v->buf_n) == 0) { a = CLAVES[i].sim; break; }
  }
  f = buscar(v->q, a, v->pila[v->tope].sim, 1);
  if (!f) { malformado(v, E_SINTAXIS, 1, lin, col, byte); return; }
  ejecutar(v, f, a, tk, lin, col, byte);
  while (!v->terminado && (f = buscar(v->q, S_EPS, v->pila[v->tope].sim, 0)) != 0)
    ejecutar(v, f, S_EPS, tk, lin, col, byte);             /* transiciones epsilon (estado R) */
}

/* ---- lexer: los AFD de la Fase 1, byte a byte ---- */
static void hundir(Dpda *v, unsigned char b) { if (v->buf_n < BUF_MAX) v->buf[v->buf_n++] = b; else v->buf_des = 1; }
static void hundir_cp(Dpda *v, uint32_t c) {
  if (c < 0x80) hundir(v, (unsigned char)c);
  else if (c < 0x800) { hundir(v, (unsigned char)(0xC0 | (c >> 6))); hundir(v, (unsigned char)(0x80 | (c & 63))); }
  else if (c < 0x10000) { hundir(v, (unsigned char)(0xE0 | (c >> 12))); hundir(v, (unsigned char)(0x80 | ((c >> 6) & 63))); hundir(v, (unsigned char)(0x80 | (c & 63))); }
  else { hundir(v, (unsigned char)(0xF0 | (c >> 18))); hundir(v, (unsigned char)(0x80 | ((c >> 12) & 63))); hundir(v, (unsigned char)(0x80 | ((c >> 6) & 63))); hundir(v, (unsigned char)(0x80 | (c & 63))); }
}
static void soltar_alto(Dpda *v) { if (v->alto) { v->alto = 0; v->no_coincide = 1; } }
static void unidad(Dpda *v, uint32_t u) {                  /* llego un \uXXXX completo */
  if (v->alto && u >= 0xDC00 && u <= 0xDFFF) { uint32_t c = 0x10000 + ((v->alto - 0xD800) << 10) + (u - 0xDC00); v->alto = 0; hundir_cp(v, c); return; }
  soltar_alto(v); v->cps++;
  if (u >= 0xD800 && u <= 0xDBFF) v->alto = u;
  else if (u >= 0xDC00 && u <= 0xDFFF) v->no_coincide = 1;
  else hundir_cp(v, u);
}
static void utf8(Dpda *v, unsigned char b) {                /* AFD de UTF-8 bien formado */
  if (v->u8_faltan == 0) {
    if (b < 0x80) return;
    v->u8_lo = 0x80; v->u8_hi = 0xBF;
    if (b >= 0xC2 && b <= 0xDF) v->u8_faltan = 1;
    else if (b == 0xE0) { v->u8_faltan = 2; v->u8_lo = 0xA0; }
    else if (b == 0xED) { v->u8_faltan = 2; v->u8_hi = 0x9F; }
    else if (b >= 0xE1 && b <= 0xEF) v->u8_faltan = 2;
    else if (b == 0xF0) { v->u8_faltan = 3; v->u8_lo = 0x90; }
    else if (b == 0xF4) { v->u8_faltan = 3; v->u8_hi = 0x8F; }
    else if (b >= 0xF1 && b <= 0xF3) v->u8_faltan = 3;
    else v->u8_malo = 1;
  } else if (b < v->u8_lo || b > v->u8_hi) { v->u8_malo = 1; v->u8_faltan = 0; }
  else { v->u8_faltan--; v->u8_lo = 0x80; v->u8_hi = 0xBF; }
}
static int hexval(unsigned char b) { return b <= '9' ? b - '0' : (b | 32) - 'a' + 10; }
static void accion(Dpda *v, unsigned char b, int cl) {       /* lo que se guarda del token mientras se lee */
  if (v->afd == A_NUM) { if (v->num_n < NUM_MAX - 1) v->num[v->num_n++] = (char)b; else v->num_des = 1; return; }
  if (v->afd == A_LIT) { if (v->lq == 0) v->lit = b; return; }
  utf8(v, b);
  if (v->lq == SC_C1) {
    if (cl == KC_COMILLA) soltar_alto(v);
    else if (cl != KC_BARRA) { soltar_alto(v); if ((b & 0xC0) != 0x80) v->cps++; hundir(v, b); }
  } else if (v->lq == SC_C3) {
    if (cl == KC_U) v->hex = 0;
    else { soltar_alto(v); v->cps++;
           hundir(v, (unsigned char)(b == 'b' ? 8 : b == 'f' ? 12 : b == 'n' ? 10 : b == 'r' ? 13 : b == 't' ? 9 : b)); }
  } else if (v->lq >= SC_C4 && v->lq <= SC_C7) {
    v->hex = v->hex * 16 + (uint32_t)hexval(b);
    if (v->lq == SC_C7) unidad(v, v->hex);
  }
}
static void lexico(Dpda *v) { if (!parado(v)) malformado(v, E_LEXICO, 1, v->linea, v->columna, v->pos); v->terminado = 1; }
static void emitir(Dpda *v) {
  int afd = v->afd, tk; v->afd = A_NADA;
  if (afd == A_CAD) { if (v->u8_malo || v->u8_faltan) { lexico(v); return; } tk = T_CADENA; v->tipo_tok = 1; }
  else if (afd == A_NUM) {
    uint32_t i; int entero = 1;
    if (v->num_des) { v->limite = E_NUMERO_LARGO; malformado(v, E_NUMERO_LARGO, 1, v->ini_linea, v->ini_columna, v->ini_pos); return; }
    v->num[v->num_n] = 0; v->valor = strtod(v->num, 0);
    for (i = 0; i < v->num_n; i++) if (v->num[i] == '.' || v->num[i] == 'e' || v->num[i] == 'E') entero = 0;
    if (!entero) entero = (v->valor - v->valor == 0.0) && floor(v->valor) == v->valor;   /* finito y sin decimales */
    tk = T_NUMERO; v->tipo_tok = 2 | (entero ? 4 : 0);
  } else { tk = T_LITERAL; v->tipo_tok = (v->lit == 'n') ? 16 : 8; }
  paso(v, tk, v->ini_linea, v->ini_columna, v->ini_pos);
}
static void avanzar(Dpda *v, unsigned char b) { v->pos++; if (b == '\n') { v->linea++; v->columna = 1; } else v->columna++; }
static void un_byte(Dpda *v, unsigned char b) {
  for (;;) {
    int cl, sig, acepta, nosigue;
    if (v->afd == A_NADA) {                                  /* entre tokens */
      if (b == ' ' || b == '\t' || b == '\n' || b == '\r') { avanzar(v, b); return; }
      if (SIMBOLO[b] >= 0) {
        v->tipo_tok = SIMBOLO[b] == T_LLAVE_A ? 32 : SIMBOLO[b] == T_CORCH_A ? 64 : 0;
        paso(v, SIMBOLO[b], v->linea, v->columna, v->pos); avanzar(v, b); return;
      }
      if (b == '"') v->afd = A_CAD; else if (b == '-' || (b >= '0' && b <= '9')) v->afd = A_NUM;
      else if (b == 't' || b == 'f' || b == 'n') v->afd = A_LIT; else { lexico(v); return; }
      v->lq = 0; v->ini_linea = v->linea; v->ini_columna = v->columna; v->ini_pos = v->pos;
      v->buf_n = 0; v->buf_des = 0; v->no_coincide = 0; v->u8_malo = 0; v->u8_faltan = 0;
      v->cps = 0; v->alto = 0; v->num_n = 0; v->num_des = 0;
    }
    if (v->afd == A_NUM) { cl = LN_CLASE[b]; sig = LN_TRANS[v->lq * LN_NC + cl]; acepta = LN_ACEPTA[v->lq]; nosigue = LN_NOSIGUE[b]; }
    else if (v->afd == A_CAD) { cl = LC_CLASE[b]; sig = LC_TRANS[v->lq * LC_NC + cl]; acepta = LC_ACEPTA[v->lq]; nosigue = LC_NOSIGUE[b]; }
    else { cl = LL_CLASE[b]; sig = LL_TRANS[v->lq * LL_NC + cl]; acepta = LL_ACEPTA[v->lq]; nosigue = LL_NOSIGUE[b]; }
    if (sig >= 0) { accion(v, b, cl); v->lq = sig; avanzar(v, b); return; }     /* hay flecha */
    if (!acepta || nosigue) { lexico(v); return; }
    emitir(v);                                               /* token completo: va al automata */
    if (parado(v)) return;
  }                                                          /* y se vuelve a mirar el mismo byte */
}

/* ===== API C-ABI (FFI) ===== */
size_t dpda_tamano(void) { return sizeof(Dpda); }            /* la memoria la pone quien llama */
void dpda_iniciar(Dpda *v, uint32_t max_prof, int parar) {
  memset(v, 0, sizeof *v);
  v->linea = 1; v->columna = 1; v->pila_max = 1; v->parar = parar;
  v->max_prof = (max_prof == 0 || max_prof > PILA_MAX) ? PILA_MAX : max_prof;
}
int dpda_alimentar(Dpda *v, const unsigned char *d, size_t n) {    /* un bloque de bytes; 1 = ya no hace falta mas */
  size_t i;
  for (i = 0; i < n; i++) { if (parado(v)) return 1; un_byte(v, d[i]); }
  return parado(v);
}
void dpda_cortar(Dpda *v, int por_tiempo) {                  /* limite de tamano o de tiempo superado */
  if (parado(v)) return;
  v->limite = por_tiempo ? E_TIEMPO : E_TAMANO; malformado(v, v->limite, 0, 0, 0, 0);
}
int dpda_terminar(Dpda *v) {                                 /* 0 valido, 1 invalido, 2 mal formado */
  if (!parado(v) && v->afd != A_NADA) {
    int acepta = v->afd == A_NUM ? LN_ACEPTA[v->lq] : v->afd == A_CAD ? LC_ACEPTA[v->lq] : LL_ACEPTA[v->lq];
    if (!acepta) lexico(v); else emitir(v);
  }
  if (!parado(v) && v->q != Q_F) malformado(v, E_INCOMPLETO, 0, 0, 0, 0);
  return v->violaciones == 0 ? 0 : (v->mal_formado ? 2 : 1);
}
uint64_t dpda_costo(const Dpda *v) { return v->costo; }
uint64_t dpda_violaciones(const Dpda *v) { return v->violaciones; }
uint64_t dpda_bytes(const Dpda *v) { return v->pos; }
uint32_t dpda_pila_max(const Dpda *v) { return v->pila_max; }
uint32_t dpda_estados(void) { return NQ; }
uint32_t dpda_transiciones(void) { return NFILAS; }

typedef struct { char *p; size_t cap, n; } Sal;
static void pon(Sal *s, const char *t) { for (; *t; t++) if (s->n + 1 < s->cap) s->p[s->n++] = *t; }
static void pon_u(Sal *s, uint64_t x) { char b[24]; snprintf(b, sizeof b, "%llu", (unsigned long long)x); pon(s, b); }
static void pon_esc(Sal *s, const char *t) {
  for (; *t; t++) { unsigned char c = (unsigned char)*t; char b[8];
    if (c == '"' || c == '\\') { b[0] = '\\'; b[1] = (char)c; b[2] = 0; } else if (c < 0x20) snprintf(b, sizeof b, "\\u%04x", c);
    else { b[0] = (char)c; b[1] = 0; }
    pon(s, b); }
}
size_t dpda_reporte(const Dpda *v, char *salida, size_t cap) {   /* el resultado como una linea JSON */
  Sal s; uint32_t i; s.p = salida; s.cap = cap; s.n = 0;
  pon(&s, "{\"valido\":"); pon(&s, v->violaciones ? "false" : "true");
  pon(&s, ",\"mal_formado\":"); pon(&s, v->mal_formado ? "true" : "false");
  pon(&s, ",\"limite\":"); if (v->limite) { pon(&s, "\""); pon(&s, NOMBRE_ERR[v->limite]); pon(&s, "\""); } else pon(&s, "null");
  pon(&s, ",\"violaciones\":"); pon_u(&s, v->violaciones); pon(&s, ",\"costo\":"); pon_u(&s, v->costo);
  pon(&s, ",\"pasos\":"); pon_u(&s, v->pasos); pon(&s, ",\"pila_max\":"); pon_u(&s, v->pila_max);
  pon(&s, ",\"bytes\":"); pon_u(&s, v->pos); pon(&s, ",\"errores\":[");
  for (i = 0; i < v->n_err; i++) {
    const Error *e = &v->errores[i];
    pon(&s, i ? ",{\"ruta\":\"" : "{\"ruta\":\""); pon_esc(&s, e->ruta);
    pon(&s, "\",\"codigo\":\""); pon(&s, NOMBRE_ERR[e->codigo]); pon(&s, "\"");
    if (e->con_pos) { pon(&s, ",\"linea\":"); pon_u(&s, e->linea); pon(&s, ",\"columna\":"); pon_u(&s, e->columna); pon(&s, ",\"byte\":"); pon_u(&s, e->byte); }
    else pon(&s, ",\"linea\":null,\"columna\":null,\"byte\":null");
    pon(&s, "}");
  }
  pon(&s, "]}");
  if (cap) salida[s.n < cap ? s.n : cap - 1] = 0;
  return s.n;
}

#ifndef SIN_MAIN
/* ===== programa de linea de comandos (con instrumentacion de la Fase 6) ===== */
#include <time.h>
#ifdef _WIN32
#include <io.h>
#include <fcntl.h>
#endif
#ifdef CONTAR_MALLOC    /* gcc ... -DCONTAR_MALLOC -static -Wl,--wrap=malloc,--wrap=calloc,--wrap=realloc */
static unsigned long N_MALLOC = 0;
void *__real_malloc(size_t); void *__real_calloc(size_t, size_t); void *__real_realloc(void *, size_t);
void *__wrap_malloc(size_t n) { N_MALLOC++; return __real_malloc(n); }
void *__wrap_calloc(size_t a, size_t b) { N_MALLOC++; return __real_calloc(a, b); }
void *__wrap_realloc(void *p, size_t n) { N_MALLOC++; return __real_realloc(p, n); }
#endif
#define LAT_MAX 65536
static Dpda V; static unsigned char ENT[65536]; static char SAL[ERR_MAX * (RUTA_MAX * 6 + 160) + 512];
static char SBUF[65536]; static uint64_t LAT[LAT_MAX];
static uint64_t ahora_ns(void) { struct timespec t; timespec_get(&t, TIME_UTC); return (uint64_t)t.tv_sec * 1000000000ull + (uint64_t)t.tv_nsec; }
static uint64_t ciclos(void) {
#if defined(__x86_64__) || defined(__i386__)
  return __builtin_ia32_rdtsc();
#else
  return 0;
#endif
}
static void ordenar(uint64_t *a, size_t n) {                 /* shell sort: sin memoria extra */
  size_t h, i, j; uint64_t x;
  for (h = n / 2; h > 0; h /= 2) for (i = h; i < n; i++) { x = a[i]; for (j = i; j >= h && a[j - h] > x; j -= h) a[j] = a[j - h]; a[j] = x; }
}
int main(int argc, char **argv) {
  int parar = 0, lote = 0, metricas = 0, silencio = 0, i, peor = 0, abierto = 0;
  uint32_t prof = 0; uint64_t max_bytes = 0, max_ms = 0, t_ns = 0, t_cic = 0, total = 0, n_docs = 0, cnt[3] = {0, 0, 0};
  uint64_t doc_bytes = 0, doc_ns = 0, doc_t0 = 0; size_t bloque = sizeof ENT, n, n_lat = 0; unsigned long m0 = 0, m1 = 0;
  for (i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--parar")) parar = 1; else if (!strcmp(argv[i], "--lote")) lote = 1;
    else if (!strcmp(argv[i], "--metricas")) metricas = 1; else if (!strcmp(argv[i], "--silencio")) silencio = 1;
    else if (!strcmp(argv[i], "--prof") && i + 1 < argc) prof = (uint32_t)strtoul(argv[++i], 0, 10);
    else if (!strcmp(argv[i], "--max-bytes") && i + 1 < argc) max_bytes = strtoull(argv[++i], 0, 10);
    else if (!strcmp(argv[i], "--max-ms") && i + 1 < argc) max_ms = strtoull(argv[++i], 0, 10);
    else if (!strcmp(argv[i], "--bloque") && i + 1 < argc) { bloque = (size_t)strtoul(argv[++i], 0, 10); if (bloque < 1 || bloque > sizeof ENT) bloque = sizeof ENT; }
    else { fprintf(stderr, "uso: %s [--parar] [--prof N] [--max-bytes N] [--max-ms N] [--bloque N] [--lote] [--metricas] [--silencio] < documento\n", argv[0]); return 3; }
  }
#ifdef _WIN32
  _setmode(_fileno(stdin), _O_BINARY);
#endif
  setvbuf(stdin, 0, _IONBF, 0); setvbuf(stdout, SBUF, _IOFBF, sizeof SBUF);
#ifdef CONTAR_MALLOC
  m0 = N_MALLOC;
#endif
  dpda_iniciar(&V, prof, parar);
  for (;;) {
    size_t a = 0; int fin;
    n = fread(ENT, 1, bloque, stdin);
    fin = (n == 0);
    while (a < n || fin) {
      size_t b = a; int cerrar = fin; uint64_t t0, c0;
      if (!fin) {
        if (lote) { while (b < n && ENT[b] != 0x1E) b++; cerrar = (b < n); } else b = n;
        if (!abierto) { abierto = 1; doc_t0 = ahora_ns(); }
        t0 = ahora_ns(); c0 = ciclos();
        if (max_bytes && doc_bytes + (b - a) > max_bytes) { dpda_alimentar(&V, ENT + a, (size_t)(max_bytes - doc_bytes)); dpda_cortar(&V, 0); }
        else dpda_alimentar(&V, ENT + a, b - a);
        doc_bytes += b - a; total += b - a;
        t_cic += ciclos() - c0; t0 = ahora_ns() - t0; t_ns += t0; doc_ns += t0;
        if (max_ms && (ahora_ns() - doc_t0) / 1000000ull > max_ms) dpda_cortar(&V, 1);
      }
      if (cerrar && (abierto || !lote)) {                    /* fin de un documento */
        uint64_t t0b = ahora_ns(), c0b = ciclos(); int r = dpda_terminar(&V);
        t_cic += ciclos() - c0b; t0b = ahora_ns() - t0b; t_ns += t0b; doc_ns += t0b;
        cnt[r]++; n_docs++; if (r > peor) peor = r;
        if (n_lat < LAT_MAX) LAT[n_lat++] = doc_ns;
        if (!silencio) { dpda_reporte(&V, SAL, sizeof SAL); fputs(SAL, stdout); fputc('\n', stdout); }
        dpda_iniciar(&V, prof, parar); doc_bytes = 0; doc_ns = 0; abierto = 0;
      }
      if (fin) break;
      a = b + (cerrar ? 1 : 0);
    }
    if (fin) break;
  }
#ifdef CONTAR_MALLOC
  m1 = N_MALLOC;
#endif
  fflush(stdout);
  if (metricas) {
    ordenar(LAT, n_lat);
    fprintf(stderr, "{\"docs\":%llu,\"validos\":%llu,\"invalidos\":%llu,\"mal_formados\":%llu,\"bytes\":%llu,\"ns\":%llu,"
            "\"mb_s\":%.2f,\"ciclos_byte\":%.2f,\"asignaciones\":%ld,\"mem_validador\":%llu,\"estados\":%d,\"transiciones\":%d,"
            "\"lat_p50_ns\":%llu,\"lat_p99_ns\":%llu,\"lat_max_ns\":%llu}\n",
            (unsigned long long)n_docs, (unsigned long long)cnt[0], (unsigned long long)cnt[1], (unsigned long long)cnt[2],
            (unsigned long long)total, (unsigned long long)t_ns, t_ns ? (double)total / 1048576.0 / ((double)t_ns / 1e9) : 0.0,
            (total && t_cic) ? (double)t_cic / (double)total : -1.0,
#ifdef CONTAR_MALLOC
            (long)(m1 - m0),
#else
            (long)-1 + (long)(m1 - m0),
#endif
            (unsigned long long)sizeof(Dpda), NQ, NFILAS,
            (unsigned long long)(n_lat ? LAT[n_lat / 2] : 0), (unsigned long long)(n_lat ? LAT[(n_lat * 99) / 100] : 0),
            (unsigned long long)(n_lat ? LAT[n_lat - 1] : 0));
  }
  return peor;
}
#endif
